# Craigsilist-gig-finder
This webapp scrapes every craigslist gig type from every city in america .

Install the requirements , run "streamlit run app.py" from your commandline in the project directory.
Pick the gig type.
Sit back and relax..
